<footer>
            <div class="footer-area">
                <p>Park Ticketing Management System @ 2019. All right reserved</p>
            </div>
        </footer>